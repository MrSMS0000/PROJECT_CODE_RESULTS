package com.sms.Synchronous;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SynchronousApplicationTests {

	@Test
	void contextLoads() {
	}

}
